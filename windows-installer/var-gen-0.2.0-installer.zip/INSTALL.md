# var-gen v0.2.0 Installation Package 
 
## Quick Installation 
1. Extract this zip file 
2. Run PowerShell as Administrator 
3. Execute: .\scripts\install.ps1 
 
## File Description 
- bin\var-gen.exe - Main program 
- scripts\install.ps1 - Installation script 
- scripts\uninstall.ps1 - Uninstallation script 
- uninstall.bat - One-click uninstall (double-click to run) 
- mapping-config-example.json - Configuration example 
 
After installation, run in any directory: var-gen --help 
